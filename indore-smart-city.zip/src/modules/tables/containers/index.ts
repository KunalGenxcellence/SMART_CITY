import { TablesComponent } from './tables/tables.component';

export const containers = [TablesComponent];

export * from './tables/tables.component';
